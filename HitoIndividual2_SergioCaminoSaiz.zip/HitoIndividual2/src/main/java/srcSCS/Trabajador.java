package srcSCS;

class Trabajador {
	//ATRIBUTOS
	private String nombre;
	private String ciudad;
	private float salarioBruto;
	private boolean contratoTemporal;

	//CONSTRUCTOR
	public Trabajador(String nombre, String ciudad, float salarioBruto, boolean contratoTemporal){
		this.nombre=nombre;
		this.ciudad=ciudad;
		this.salarioBruto=salarioBruto;
		this.contratoTemporal=contratoTemporal;
	}
	
	
	
	//GETTERS & SETTERS
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public float getSalarioBruto() {
		return salarioBruto;
	}

	public void setSalarioBruto(float salarioBruto) {
		this.salarioBruto = salarioBruto;
	}

	public boolean isContratoTemporal() {
		return contratoTemporal;
	}

	public void setContratoTemporal(boolean contratoTemporal) {
		this.contratoTemporal = contratoTemporal;
	}



	
	
	
	//METODOS GEN�RICOS
	@Override
	public String toString() {
		return "Trabajador [nombre=" + nombre + ", ciudad=" + ciudad + ", salarioBruto=" + salarioBruto + ", contratoTemporal=" + contratoTemporal + "]";
	}
	
	
	
	
	
	
}//cierra clase
