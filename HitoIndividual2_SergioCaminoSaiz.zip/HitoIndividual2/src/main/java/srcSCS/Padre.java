package srcSCS;


//PARA QUE LA CLASE NO SEA INSTANCIADA LE PONDRE EL VALOR ABSTRACT PARA QUE NO SE PUEDA INSTANCIAR
public abstract class Padre {
	//ATRIBUTOS
	private String texto;
	private int numeroEntero;
	
	
	//CONSTRUCTOR
	public Padre(String texto, int numeroEntero){
		this.texto=texto;
		this.numeroEntero=numeroEntero;
	}
	
	
	//METODO GEN�RICO
	public void Saludar(){
		System.out.println("Hola soy el padre");
	}
	
	
	
	
}//cierra clase
