package srcSCS;



public class principal {

	//INSTANCIAR LA CLASE HIJA
	Hija hija1=new Hija("Hija1", 2);
	hija1.Saludar();
	
}//cierra clase
