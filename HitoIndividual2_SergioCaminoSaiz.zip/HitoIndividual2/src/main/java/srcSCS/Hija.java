package srcSCS;

public class Hija extends Padre {
	
	public Hija(String texto, int numeroEntero) {
	super(texto, numeroEntero);
	}

		//ESTE METODO ES OVERRIDE PORQUE SOBREESCRIBE EL METODO SALUDAR DE LA CLASE PADRE
		public void Saludar(){
			System.out.println("Hola soy el hija");
		}
}//cierra la clase
